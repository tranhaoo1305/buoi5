// ignore_for_file: use_full_hex_values_for_flutter_colors
import 'package:flutter/material.dart';

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
       title: 'o7planning.org',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        primarySwatch: Colors.blue,
        visualDensity: VisualDensity.adaptivePlatformDensity,
      ),
      home: const MyHomePage(title: 'Flutter Demo Home Page'),
    );
  }
}

class MyHomePage extends StatefulWidget {
  const MyHomePage({super.key, required this.title});
  final String title;

  @override
  State<MyHomePage> createState() => _MyHomePageState();
}

class _MyHomePageState extends State<MyHomePage> {
  @override
  Widget build(BuildContext context) {
     // ignore: unnecessary_null_comparison
    return Scaffold(
      appBar: AppBar(
          title: const Text("Flutter RoundedRectangleBorder Example")
      ),
      body: ElevatedButton(
        onPressed: () {},
        style: ElevatedButton.styleFrom( 
          backgroundColor: Colors.red,
          foregroundColor: Colors.white,
          side: const BorderSide(color: Colors.green, width: 3), 
          shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(32.0),
              side: const BorderSide(color: Colors.yellow, width: 3) 
          ),
        ),
        child: const Text("ElevatedButton"),
      )
    );
  }
}