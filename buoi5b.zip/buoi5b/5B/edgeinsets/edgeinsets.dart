// ignore_for_file: use_full_hex_values_for_flutter_colors
import 'package:flutter/material.dart';

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
       title: 'o7planning.org',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        primarySwatch: Colors.blue,
        visualDensity: VisualDensity.adaptivePlatformDensity,
      ),
      home: const MyHomePage(title: 'Flutter Demo Home Page'),
    );
  }
}

class MyHomePage extends StatefulWidget {
  const MyHomePage({super.key, required this.title});
  final String title;

  @override
  State<MyHomePage> createState() => _MyHomePageState();
}

class _MyHomePageState extends State<MyHomePage> {
  @override
  Widget build(BuildContext context) {
     // ignore: unnecessary_null_comparison
    return Scaffold(
      appBar: AppBar(
           title: const Text("Flutter EdgeInsets Example")
        ),
        body: Directionality (
            textDirection: TextDirection.rtl,
            child:  Row (
              children: [
               Container (
                    margin: const EdgeInsets.all(80),
                    color: Colors.greenAccent,
                    child:const Text(
                        "Hi There!",
                        style: TextStyle(fontSize: 28)
                    )
                ),
                Padding (
                    padding: const EdgeInsets.fromLTRB(80, 100, 70, 50),
                    child: ElevatedButton (
                        child: const Text("Button"),
                        onPressed: (){}
                    )
                ),
                Container (
                    color: Colors.greenAccent,
                    padding: const EdgeInsets.only(left: 120, top: 50, right: 80),
                    child: ElevatedButton (
                        child: const Text("Button"),
                        onPressed: (){}
                    )
                ),
                Container (
                    color: Colors.greenAccent,
                    padding: const EdgeInsets.symmetric(horizontal: 120, vertical: 50),
                    child: ElevatedButton (
                        child: const Text("Button"),
                        onPressed: (){}
                    )
                )
              ],
            )
        )
    );
  }
}