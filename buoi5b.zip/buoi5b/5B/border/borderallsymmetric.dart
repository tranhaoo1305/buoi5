// ignore_for_file: use_full_hex_values_for_flutter_colors
import 'package:flutter/material.dart';

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
       title: 'o7planning.org',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        primarySwatch: Colors.blue,
        visualDensity: VisualDensity.adaptivePlatformDensity,
      ),
      home: const MyHomePage(title: 'Flutter Demo Home Page'),
    );
  }
}

class MyHomePage extends StatefulWidget {
  const MyHomePage({super.key, required this.title});
  final String title;

  @override
  State<MyHomePage> createState() => _MyHomePageState();
}

class _MyHomePageState extends State<MyHomePage> {
  @override
  Widget build(BuildContext context) {
     // ignore: unnecessary_null_comparison
    return Scaffold(
      appBar: AppBar(
          title: const Text("Flutter Border Example")
      ),
      body: Container(
            width: 250,
            height: 100,
            alignment: Alignment.center,
            decoration: const BoxDecoration(
              border: Border.symmetric (
                vertical: BorderSide (
                    width: 5,
                    color: Colors.green,
                    style: BorderStyle.solid
                ),
                horizontal:  BorderSide (
                  width: 3,
                  color: Colors.blue,
                  style: BorderStyle.solid
              ),
            ),
          ),
          child: const Text("Flutter")
      )
    );
  }
}