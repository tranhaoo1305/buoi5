// ignore_for_file: use_full_hex_values_for_flutter_colors
import 'package:flutter/material.dart';

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
       title: 'o7planning.org',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        primarySwatch: Colors.blue,
        visualDensity: VisualDensity.adaptivePlatformDensity,
      ),
      home: const MyHomePage(title: 'Flutter Demo Home Page'),
    );
  }
}

class MyHomePage extends StatefulWidget {
  const MyHomePage({super.key, required this.title});
  final String title;

  @override
  State<MyHomePage> createState() => _MyHomePageState();
}

class _MyHomePageState extends State<MyHomePage> {
  @override
  Widget build(BuildContext context) {
     // ignore: unnecessary_null_comparison
    return Scaffold(
      appBar: AppBar(
          title: const Text("Flutter Border Example")
      ),
      body: Container(
          decoration:  const BoxDecoration(
            border: Border(
              top: BorderSide(width: 1.0, color: Color(0xffffffffff)),
              left: BorderSide(width: 1.0, color: Color(0xffffffffff)),
              right: BorderSide(width: 1.0, color: Color(0xffff000000)),
              bottom: BorderSide(width: 1.0, color: Color(0xffff000000)),
        ),
      ),
      child: Container(
        width: 200,
        height: 50,
        padding:  const EdgeInsets.symmetric(horizontal: 20.0, vertical: 2.0),
        alignment: Alignment.center,
        decoration: const BoxDecoration(
          border: Border(
            top: BorderSide(width: 1.0, color: Color(0xffffdfdfdf)),
            left: BorderSide(width: 1.0, color: Color(0xffffdfdfdf)),
            right: BorderSide(width: 1.0, color: Color(0xffff7f7f7f)),
            bottom: BorderSide(width: 1.0, color: Color(0xffff7f7f7f)),
          ),
          color: Color(0xFFBFBFBF),
        ),
          child: const Text(
              'OK',
              textAlign: TextAlign.center,
              style: TextStyle(color: Color(0xFF000000))
          ),
        ),
      )
    );
  }
}