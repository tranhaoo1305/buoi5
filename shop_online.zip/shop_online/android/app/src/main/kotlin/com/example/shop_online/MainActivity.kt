package com.example.shop_online

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
