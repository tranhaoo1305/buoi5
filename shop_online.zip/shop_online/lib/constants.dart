import 'package:flutter/material.dart';

const Color kTextColor = Color(0xFF535353);
const Color kTextLightColor = Color(0xFFACACAC);

const double kDefaultPadding = 20.0;