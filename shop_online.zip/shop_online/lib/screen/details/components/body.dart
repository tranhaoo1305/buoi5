import 'package:flutter/material.dart';

import '../../../constants.dart';
import '../../../models/product.dart';
import 'add_to_cart.dart';
import 'color_and_size.dart';
import 'counter_with_fav_btn.dart';
import 'description.dart';
import 'product_title_with_image.dart';

class Body extends StatelessWidget {
  final Product? product;

  const Body({super.key, this.product});

  @override
  Widget build(BuildContext context) {
    Size size = MediaQuery.of(context).size;
    return SingleChildScrollView(
      child: Column(
        children: [
          Stack(
            children: [
              Container(
                margin: EdgeInsets.only(top: size.height * 0.32),
                padding: EdgeInsets.only(
                    top: size.height * 0.15,
                    left: kDefaultPadding,
                    right: kDefaultPadding),
                height: 550.0,
                decoration: const BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.only(
                      topLeft: Radius.circular(25),
                      topRight: Radius.circular(25)),
                ),
                child: Column(
                  children: [
                    ColorAndSize(product: product),
                    const SizedBox(height: kDefaultPadding / 2),
                    Description(product: product),
                    const SizedBox(height: kDefaultPadding / 2),
                    const CounterWithFavBtn(),
                    const SizedBox(height: kDefaultPadding / 2),
                    AddToCart(product: product),
                  ],
                ),
              ),
              ProductTitleWithImage(product: product),
            ],
          ),
        ],
      ),
    );
  }
}
