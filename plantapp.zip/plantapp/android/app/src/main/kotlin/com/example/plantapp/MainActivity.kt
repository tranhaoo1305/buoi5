package com.example.plantapp

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
